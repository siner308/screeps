
module.exports = {
    get_role_name: function(){
        return [
            'harvester',
            'upgrader',
            'builder',
            'repairer',
            'miner1',
            'miner2',
            'cleaner'
            ]
    },
    
    get_role_type: function(){
        return [
            'c_h_',
            'c_u_',
            'c_b_',
            'c_r_',
            'c_m_',
            'c_m2_',
            'c_c_'
            ]
    },
    get_role_population_max: function(){
        return [
            2,  // harvester
            4, // upgrader
            2,  // builder
            2,  // repairer
            1,   // miner
            2,   // miner2
            2,   // cleaner
            // 1   // cleaner2
          ]
    },
    
    get_body_spec: function(){
        return [
            [1,2,1,0,3,0,0,3],
            [1,1,1,0,0,0,0,0],
            [1,1,1,0,0,0,0,0],
            [1,1,1,0,0,0,0,0],
            [1,1,1,0,0,0,0,0],
            [1,1,1,0,0,0,0,0],
            [1,1,1,0,0,0,0,0],
            [1,1,1,0,0,0,0,0]
            ]
    },
    
    get_body_type: function(){
        return BODYPARTS_ALL
    },
    
    get_single_type_body: function(input, target){
        var str_body = '';
        for(var i = 0; i < input; i++){
            str_body += this.get_body_type()[target];
            // console.log(this.get_body_type());
            
            if(input > i + 1) {
                str_body += ',';
            }
        }
        // console.log(str_body);
        return str_body;
    },
        
    
    get_role_spec: function(num_body){
        // MOVE, WORK, CARRY, ATTACK, RANGED_ATTACK, HEAL, CLAIM, TOUGH
        var i = 0;
        var retStr = '[';

        for (i = 0; i < 8; i++){
            retStr += this.get_single_type_body(num_body[i], i);
            if(i != 7 && num_body[i + 1]){
                retStr += ',';
            }
        }
        retStr += ']';
        return retStr;
    },
    
    get_role_count:function(){
        return[        
            _.filter(Game.creeps, (creep) => creep.memory.role == this.get_role_name[0]).length,
            _.filter(Game.creeps, (creep) => creep.memory.role == this.get_role_name[1]).length,
            _.filter(Game.creeps, (creep) => creep.memory.role == this.get_role_name[2]).length,
            _.filter(Game.creeps, (creep) => creep.memory.role == this.get_role_name[3]).length,
            _.filter(Game.creeps, (creep) => creep.memory.role == this.get_role_name[4]).length,
            _.filter(Game.creeps, (creep) => creep.memory.role == this.get_role_name[5]).length,
            _.filter(Game.creeps, (creep) => creep.memory.role == this.get_role_name[6]).length,
            _.filter(Game.creeps, (creep) => creep.memory.role == this.get_role_name[7]).length
        ]
    }
};