module.exports = {
    containers: function(creep){
        let container = creep.pos.findClosestByPath(FIND_STRUCTURES, {
            filter: c => (c.structureType == STRUCTURE_CONTAINER)
                && (c.store[RESOURCE_ENERGY] != 0)
        });
        return container;
    }
};